﻿using CookComputing.XmlRpc;
using System;
using System.Diagnostics;
using System.IO;
using System.Collections;
using System.Xml;

namespace WirelessHARTmonitor
{
    public class LoginRequest
    {
        public string username { get; set; }
        public string password { get; set; }
    }
    public class LoginResponse
    {
        public string loginToken { get; set; }
    }
    public class SubscribeRequest
    {
        string token;
        string filter;
    }
    public class SubsribeResponse
    {
        string token;
        string port;
    }
    public class DataNotificationElements
    {
        int moteId;
        string macAddr;
        int time;
        string payload;
        object isReliable, isRequest, isBroadcast;
        int callbackId;
        int counter;
    }

    public static class HartGlobals
    {
        public static string username;
        public static string password;
        public static string URL;
        public static string urlIP;
        public static string loginToken;
        public static string notificationToken;
        public static int notificationPort;
        public static string moteMacAddress;
        public static string motePath;
        public static int moteCount;
        public static bool preventPacket = true;
        public static string allMoteXml;
        public static string followed_mote_MAC;
    }

    public interface DustInterface : IXmlRpcProxy
    {
        [XmlRpcMethod("login")]
        string login(string username, string password);

        [XmlRpcMethod("logout")]
        string logout(string lt);

        [XmlRpcMethod("getConfig")]
        string getConfig(string loginToken, string depth, string query);

        [XmlRpcMethod("subscribe")]
        object[] subscribe(string loginToken, string depth);
    }

    public class dustManager
    {
        public bool loginToManager(string ipAddress, string userName, string passWord)
        {


            string URL = "http://" + ipAddress + ":4445";
            HartGlobals.URL = URL;
            HartGlobals.urlIP = ipAddress;
            Tracer tracer = new Tracer();
            DustInterface proxy = XmlRpcProxyGen.Create<DustInterface>();
            proxy.Url = URL;
            tracer.SubscribeTo(proxy);
            try
            {
                HartGlobals.loginToken = proxy.login("admin", "admin");
            }
            catch (Exception)
            {
                return false;
            }
            return true;

        }
        public bool logoutOfManager()
        {
            Tracer tracer = new Tracer();
            DustInterface proxy = XmlRpcProxyGen.Create<DustInterface>();
            proxy.Url = HartGlobals.URL;
            tracer.SubscribeTo(proxy);
            try
            {
                if (proxy.logout(HartGlobals.loginToken) == "OK")
                    return true;
                else
                    return false;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public IList ListMotes()
        {
            string xmlResponse;
            string depth = "all";
            string query = "<Motes> </Motes>";
            ArrayList ret = new ArrayList();
            Tracer tracer = new Tracer();
            DustInterface proxy = XmlRpcProxyGen.Create<DustInterface>();
            proxy.Url = HartGlobals.URL;
            tracer.SubscribeTo(proxy);

            xmlResponse = proxy.getConfig(HartGlobals.loginToken, depth, query);
            HartGlobals.allMoteXml = xmlResponse;

            //xml processing
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(xmlResponse);


            //Xml Parsing
            XmlNodeList moteId = xmlDoc.GetElementsByTagName("moteId"); // parse moteIds
            XmlNodeList moteMacAddresses = xmlDoc.GetElementsByTagName("macAddr"); //parse mac addresses
            XmlNodeList moteState = xmlDoc.GetElementsByTagName("state"); //parse states
            XmlNodeList moteVoltage = xmlDoc.GetElementsByTagName("voltage"); //parse voltages
            XmlNodeList motePowerSource = xmlDoc.GetElementsByTagName("powerSource"); //parse mote powersource
            XmlNodeList moteIsAccessPoint = xmlDoc.GetElementsByTagName("isAccessPoint"); //parase mote aces point
            XmlNodeList moteNumJoins = xmlDoc.GetElementsByTagName("numJoins"); //parse mote's number join times
            XmlNodeList moteJoinTime = xmlDoc.GetElementsByTagName("joinTime"); //parse mote's join Time

            HartGlobals.moteCount = moteId.Count;

            for(int i = 0; i < moteMacAddresses.Count; i++)
            {
                if(moteState[i].InnerText.ToString() == "Operational")
                ret.Add(moteMacAddresses[i].InnerText.ToString());
            }
            return ret;

        }
        public object[] subscribeToData()
        {
            Tracer tracer = new Tracer();
            DustInterface proxy = XmlRpcProxyGen.Create<DustInterface>();
            proxy.Url = HartGlobals.URL;
            return proxy.subscribe(HartGlobals.loginToken, "data");
        }
    }

    public class Tracer : XmlRpcLogger
    {
        protected override void OnRequest(object sender,
          XmlRpcRequestEventArgs e)
        {
            DumpStream(e.RequestStream);
        }

        protected override void OnResponse(object sender,
          XmlRpcResponseEventArgs e)
        {
            DumpStream(e.ResponseStream);
        }

        private void DumpStream(Stream stm)
        {
            stm.Position = 0;
            TextReader trdr = new StreamReader(stm);
            String s = trdr.ReadLine();
            while (s != null)
            {
                Trace.WriteLine(s);
                s = trdr.ReadLine();
            }
        }
    }
}
