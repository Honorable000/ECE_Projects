﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using CookComputing.XmlRpc;

namespace WirelessHARTmonitor
{
    public partial class Form1 : Form
    {
        dustManager dm = new dustManager();
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            if (btn_login.Text == "Login")
            {
                HartGlobals.username = tb_Username.Text;
                HartGlobals.password = tb_psswd.Text;
                HartGlobals.urlIP = tb_address.Text;
                if (dm.loginToManager(HartGlobals.urlIP, HartGlobals.username, HartGlobals.password))
                {
                    label_output.Text = "Successfully connected to Manager at " + HartGlobals.URL.ToString();
                    tb_address.Enabled = false;
                    tb_psswd.Enabled = false;
                    tb_Username.Enabled = false;
                    btn_login.Text = "Logout";

                    comboBox_follow_mote.DataSource = dm.ListMotes();
                    comboBox_follow_mote.DropDownStyle = ComboBoxStyle.DropDownList;

                }
                else
                {
                    label_output.Text = "ERROR: exception thrown in loginToManager";
                }
            }
            else
            {
                tb_address.Enabled = true;
                tb_psswd.Enabled = true;
                tb_Username.Enabled = true;

                if (dm.logoutOfManager())
                {
                    tb_address.Enabled = true;
                    tb_psswd.Enabled = true;
                    tb_Username.Enabled = true;
                    btn_login.Text = "Login";
                    label_output.Text = "Successfully disconnected to Manager at " + HartGlobals.URL.ToString();
                }
                else
                {
                    label_output.Text = "ERROR: exception thrown in logoutOfManager or Invalid Authentication";
                }
            }

        }

        private void button_subscribe_Click(object sender, EventArgs e)
        {
            object[] NotificationResponse = dm.subscribeToData();
            HartGlobals.notificationPort = Convert.ToInt32(NotificationResponse[1]);
            HartGlobals.notificationToken = NotificationResponse[0].ToString();
            HartGlobals.followed_mote_MAC = (string)comboBox_follow_mote.SelectedItem;
            backgroundWorker1.RunWorkerAsync();
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            string message = "<dustnet><authrq><token>" + HartGlobals.notificationToken + "</token></authrq></dustnet>";
            String responseData = "Failed TCP connection";

            /************************************Create a TcpClient.**********************************************///                                                                                                 //TcpClient hartClient = new TcpClient(HartGlobals.urlIP, HartGlobals.notificationPort);
            TcpClient hartClient = new TcpClient(HartGlobals.urlIP, HartGlobals.notificationPort);


            // Translate the passed message into ASCII and store it as a Byte array.
            Byte[] data = System.Text.Encoding.ASCII.GetBytes(message);


            // Get a client stream for reading and writing.
            //  Stream stream = client.GetStream();
            NetworkStream stream = hartClient.GetStream();


            // Send the message to the connected TcpServer. 
            stream.Write(data, 0, data.Length);



            /*********************Receive the TcpServer.response **********************************///
            bool flag = true;

            while (true)
            {

                // Buffer to store the response bytes.
                data = new Byte[1024];
                XmlDocument xmlDoc = new XmlDocument();
                // String to store the response ASCII representation.
                responseData = String.Empty;

                // Read the first batch of the TcpServer response bytes.
                Int32 bytes = stream.Read(data, 0, data.Length);
                responseData = System.Text.Encoding.ASCII.GetString(data, 0, bytes);

                //prevent first packet to be parsed
                if (flag) { flag = false; }

                else
                {
                        xmlDoc.LoadXml(responseData);

                        //Xml parsing
                        XmlNodeList moteID = xmlDoc.GetElementsByTagName("moteId");
                        XmlNodeList moteMacAddresses = xmlDoc.GetElementsByTagName("macAddr"); //parse mac addresses
                        XmlNodeList payLoad = xmlDoc.GetElementsByTagName("payload");

                        for (int i = 0; i < moteMacAddresses.Count; i++)
                        {
                            if (moteMacAddresses[i].InnerText.ToString() == HartGlobals.followed_mote_MAC)
                            {
                                backgroundWorker1.ReportProgress(0, payLoad[i].InnerText.ToString());
                            }
                        }





                    //check if the cancellation is requested
                    if (backgroundWorker1.CancellationPending)
                    {
                        //set cancel property of Do workEnvetsArgs object to true
                        e.Cancel = true;
                        backgroundWorker1.ReportProgress(0, "stopped");
                        hartClient.Close();
                        return;
                    }

                }
            }
        }

        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            textBox_TCP.Text += e.UserState.ToString() + "\r\n";
            uint num = uint.Parse(e.UserState.ToString(), System.Globalization.NumberStyles.AllowHexSpecifier);

            byte[] floatVals = BitConverter.GetBytes(num);
            float f = BitConverter.ToSingle(floatVals, 0);
            textBox_converted.Text += f.ToString() + "\r\n";
        }
    }
}
