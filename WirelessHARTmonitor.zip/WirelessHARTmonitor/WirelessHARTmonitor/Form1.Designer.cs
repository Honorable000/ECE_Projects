﻿namespace WirelessHARTmonitor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_login = new System.Windows.Forms.Button();
            this.label_output = new System.Windows.Forms.Label();
            this.gb_output = new System.Windows.Forms.GroupBox();
            this.tb_Username = new System.Windows.Forms.TextBox();
            this.tb_psswd = new System.Windows.Forms.TextBox();
            this.tb_address = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label_IP = new System.Windows.Forms.Label();
            this.comboBox_follow_mote = new System.Windows.Forms.ComboBox();
            this.label_mote_combo = new System.Windows.Forms.Label();
            this.button_subscribe = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.textBox_TCP = new System.Windows.Forms.TextBox();
            this.textBox_converted = new System.Windows.Forms.TextBox();
            this.gb_output.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(31, 126);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(75, 23);
            this.btn_login.TabIndex = 0;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // label_output
            // 
            this.label_output.AutoSize = true;
            this.label_output.Location = new System.Drawing.Point(6, 16);
            this.label_output.Name = "label_output";
            this.label_output.Size = new System.Drawing.Size(0, 13);
            this.label_output.TabIndex = 1;
            // 
            // gb_output
            // 
            this.gb_output.Controls.Add(this.label_output);
            this.gb_output.Location = new System.Drawing.Point(12, 304);
            this.gb_output.Name = "gb_output";
            this.gb_output.Size = new System.Drawing.Size(752, 134);
            this.gb_output.TabIndex = 2;
            this.gb_output.TabStop = false;
            this.gb_output.Text = "Output";
            // 
            // tb_Username
            // 
            this.tb_Username.Location = new System.Drawing.Point(6, 61);
            this.tb_Username.Name = "tb_Username";
            this.tb_Username.Size = new System.Drawing.Size(100, 20);
            this.tb_Username.TabIndex = 3;
            this.tb_Username.Text = "admin";
            // 
            // tb_psswd
            // 
            this.tb_psswd.Location = new System.Drawing.Point(6, 100);
            this.tb_psswd.Name = "tb_psswd";
            this.tb_psswd.Size = new System.Drawing.Size(100, 20);
            this.tb_psswd.TabIndex = 4;
            this.tb_psswd.Text = "admin";
            // 
            // tb_address
            // 
            this.tb_address.Location = new System.Drawing.Point(6, 22);
            this.tb_address.Name = "tb_address";
            this.tb_address.Size = new System.Drawing.Size(100, 20);
            this.tb_address.TabIndex = 5;
            this.tb_address.Text = "10.0.35.93";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Password";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Username";
            // 
            // label_IP
            // 
            this.label_IP.AutoSize = true;
            this.label_IP.Location = new System.Drawing.Point(3, 6);
            this.label_IP.Name = "label_IP";
            this.label_IP.Size = new System.Drawing.Size(45, 13);
            this.label_IP.TabIndex = 8;
            this.label_IP.Text = "Address";
            // 
            // comboBox_follow_mote
            // 
            this.comboBox_follow_mote.FormattingEnabled = true;
            this.comboBox_follow_mote.Location = new System.Drawing.Point(6, 172);
            this.comboBox_follow_mote.Name = "comboBox_follow_mote";
            this.comboBox_follow_mote.Size = new System.Drawing.Size(201, 21);
            this.comboBox_follow_mote.TabIndex = 9;
            // 
            // label_mote_combo
            // 
            this.label_mote_combo.AutoSize = true;
            this.label_mote_combo.Location = new System.Drawing.Point(3, 156);
            this.label_mote_combo.Name = "label_mote_combo";
            this.label_mote_combo.Size = new System.Drawing.Size(112, 13);
            this.label_mote_combo.TabIndex = 10;
            this.label_mote_combo.Text = "Follow a Specifc Mote";
            // 
            // button_subscribe
            // 
            this.button_subscribe.Location = new System.Drawing.Point(6, 199);
            this.button_subscribe.Name = "button_subscribe";
            this.button_subscribe.Size = new System.Drawing.Size(75, 23);
            this.button_subscribe.TabIndex = 11;
            this.button_subscribe.Text = "Subscribe";
            this.button_subscribe.UseVisualStyleBackColor = true;
            this.button_subscribe.Click += new System.EventHandler(this.button_subscribe_Click);
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.WorkerReportsProgress = true;
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            this.backgroundWorker1.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.backgroundWorker1_ProgressChanged);
            // 
            // textBox_TCP
            // 
            this.textBox_TCP.Location = new System.Drawing.Point(289, 22);
            this.textBox_TCP.Multiline = true;
            this.textBox_TCP.Name = "textBox_TCP";
            this.textBox_TCP.Size = new System.Drawing.Size(134, 276);
            this.textBox_TCP.TabIndex = 12;
            // 
            // textBox_converted
            // 
            this.textBox_converted.Location = new System.Drawing.Point(468, 22);
            this.textBox_converted.Multiline = true;
            this.textBox_converted.Name = "textBox_converted";
            this.textBox_converted.Size = new System.Drawing.Size(203, 276);
            this.textBox_converted.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBox_converted);
            this.Controls.Add(this.textBox_TCP);
            this.Controls.Add(this.button_subscribe);
            this.Controls.Add(this.label_mote_combo);
            this.Controls.Add(this.comboBox_follow_mote);
            this.Controls.Add(this.label_IP);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_address);
            this.Controls.Add(this.tb_psswd);
            this.Controls.Add(this.tb_Username);
            this.Controls.Add(this.gb_output);
            this.Controls.Add(this.btn_login);
            this.Name = "Form1";
            this.Text = "WirelessHART monitor";
            this.gb_output.ResumeLayout(false);
            this.gb_output.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Label label_output;
        private System.Windows.Forms.GroupBox gb_output;
        private System.Windows.Forms.TextBox tb_Username;
        private System.Windows.Forms.TextBox tb_psswd;
        private System.Windows.Forms.TextBox tb_address;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label_IP;
        private System.Windows.Forms.ComboBox comboBox_follow_mote;
        private System.Windows.Forms.Label label_mote_combo;
        private System.Windows.Forms.Button button_subscribe;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.TextBox textBox_TCP;
        private System.Windows.Forms.TextBox textBox_converted;
    }
}

